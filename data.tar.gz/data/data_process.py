import pandas as pd
import dill
import numpy as np
from collections import defaultdict
from transformers import AutoTokenizer

##### indexing file and final record
class Voc(object):
    def __init__(self):
        self.idx2word = {}
        self.word2idx = {}

    def add_sentence(self, sentence):
        for word in sentence:
            if word not in self.word2idx:
                self.idx2word[len(self.word2idx)] = word
                self.word2idx[word] = len(self.word2idx)

# create voc set
def create_str_token_mapping(df, vocabulary_file):
    diag_voc = Voc()
    med_voc = Voc()
    sym_voc = Voc()
    for index, row in df.iterrows():
        sym_voc.add_sentence(row["SYM_LIST"])
        diag_voc.add_sentence(row["ICD_C_V"])
        med_voc.add_sentence(row["ATC3"])
    dill.dump(
        obj={"sym_voc": sym_voc, "diag_voc": diag_voc, "med_voc": med_voc},
        file=open(vocabulary_file, "wb"),
    )
    return sym_voc, diag_voc, med_voc, 


def get_real_length(items,ex_nums,ids): #items表示原来元素的长度，ex_nums是超出的tokens数，按比例给出每个items应该去除的数
    if len(items) >= 3 :
        items=np.array(items)
        all_length = sum(items[:-1])+items[-1]/2
        n = np.array([round(ex_nums*(i/all_length)) for i in items[:-1]])
        lastn = ex_nums-sum(n)
        n=n.tolist()+[lastn]
        new_ids =[ids[index][:-ni] if ni!=0 else ids[index] for index,ni in enumerate(n)]
    else:
        items=np.array(items)
        all_length = sum(items[:-1])+items[-1]
        n = np.array([round(ex_nums*(i/all_length)) for i in items[:-1]])
        lastn = ex_nums-sum(n)
        n=n.tolist()+[lastn]
        new_ids =[ids[index][:-ni] if ni!=0 else ids[index] for index,ni in enumerate(n)]

    return new_ids


def create_patient_record_fix(df,  sym_voc, diag_voc, med_voc, tokenizer, ehr_sequence_file):
    records = []  # (patient, code_kind:3, codes)  code_kind:diag, sym, med 
    #根据预训练模型的special tokens 更改
    start_token_id = end_token_id = 2
    pad_token_id = 1
    prompt_end_token_id = 0
    encoder_start_token_id =0

    for subject_id in df["SUBJECT_ID"].unique():
        item_df = df[df["SUBJECT_ID"] == subject_id]
        patient = []
        svoc = []
        dvoc = []
        mvoc = []
        stext_ids=[]
        dtext_ids=[]
        mtext_ids=[]
        stext_ids_lens=[]
        dtext_ids_lens=[]
        mtext_ids_lens=[]
        train_d_inp_ids_lens=[]
        train_m_inp_ids_lens=[]
        train_s_inp_ids_lens=[]


        admission_rec=[]
        text_rec = []
        t=0
        for index, row in item_df.iterrows():
            #remove eos sos token
            admission=[]
            admission.append([sym_voc.word2idx[j] for j in row["SYM_LIST"]])
            admission.append([diag_voc.word2idx[j] for j in row["ICD_C_V"]])
            admission.append([med_voc.word2idx[j] for j in row["ATC3"]])
            admission_rec.append(admission)

            text_rec.extend([row['chief'],row['his'], row['med']])

            stext_ids.append(tokenizer.convert_tokens_to_ids(tokenizer.tokenize(row['chief'])))
            dtext_ids.append(tokenizer.convert_tokens_to_ids(tokenizer.tokenize(row['his'])))
            mtext_ids.append(tokenizer.convert_tokens_to_ids(tokenizer.tokenize(row['med'])))
            
            stext_ids_lens.append(len(stext_ids[t][:20]))
            dtext_ids_lens.append(len(dtext_ids[t][:490]))
            mtext_ids_lens.append(len(mtext_ids[t][:490]))
            train_d_inp_ids_lens.append(len(stext_ids[t][:20]))
            train_m_inp_ids_lens.append(len(stext_ids[t][:20])+len(dtext_ids[t][:490]))
            train_s_inp_ids_lens.append(len(dtext_ids[t][:490])+len(mtext_ids[t][:490]))
            t+=1

        # 和model.generate的词数相近
        s_maxlen = max(np.array(stext_ids_lens))
        d_maxlen = max(np.array(dtext_ids_lens))
        m_maxlen = max(np.array(mtext_ids_lens))
        train_d_maxlen = max(np.array(train_d_inp_ids_lens))
        train_m_maxlen = max(np.array(train_m_inp_ids_lens))
        train_s_maxlen = max(np.array(train_s_inp_ids_lens))

        patient=[]
        for i in range(len(item_df)):
            gth_ids=[]
            in_ids=[]
            real_ids=[]
            train_enc_inp = []

            s_tmp_ids = stext_ids[i][:20]
            d_tmp_ids = dtext_ids[i][:490]
            m_tmp_ids = mtext_ids[i][:490]
            
            g_s_ids = s_tmp_ids+[end_token_id]+[-100]*(s_maxlen-len(s_tmp_ids))
            in_s_ids = [start_token_id]+s_tmp_ids+[pad_token_id]*(s_maxlen-len(s_tmp_ids))
            real_ids.append(s_tmp_ids)

            g_d_ids = dtext_ids[i][:490]+[end_token_id]+[-100]*(d_maxlen-len(d_tmp_ids))
            in_d_ids = [start_token_id]+dtext_ids[i][:490]+[pad_token_id]*(d_maxlen-len(d_tmp_ids))
            real_ids.append(dtext_ids[i][:490])
            train_enc_d_in =[encoder_start_token_id] + stext_ids[i][:20] + [pad_token_id]*(train_d_maxlen-train_d_inp_ids_lens[i])
            train_enc_inp.append(train_enc_d_in)

            g_m_ids = mtext_ids[i][:490]+[end_token_id]+[-100]*(m_maxlen-len(m_tmp_ids))
            in_m_ids = [start_token_id]+mtext_ids[i][:490]+[pad_token_id]*(m_maxlen-len(m_tmp_ids))
            real_ids.append(mtext_ids[i][:490])
            train_enc_m_in = [encoder_start_token_id] + stext_ids[i][:20] + dtext_ids[i][:490] + [pad_token_id]*(train_m_maxlen-train_m_inp_ids_lens[i])
            train_enc_inp.append(train_enc_m_in)

            train_enc_s_in =[encoder_start_token_id] + dtext_ids[i][:490] + mtext_ids[i][:490] + [pad_token_id]*(train_s_maxlen-train_s_inp_ids_lens[i])
            train_enc_inp.append(train_enc_s_in)

            assert len(g_s_ids) == len(in_s_ids) == s_maxlen+1  
            assert len(g_d_ids) == len(in_d_ids) == d_maxlen+1
            assert len(g_m_ids) == len(in_m_ids) == m_maxlen+1
            assert len(train_enc_d_in) == train_d_maxlen+1
            assert len(train_enc_m_in) == train_m_maxlen+1
            assert len(train_enc_s_in) == train_s_maxlen+1

            gth_ids.extend([g_s_ids,g_d_ids,g_m_ids])
            in_ids.extend([in_s_ids,in_d_ids,in_m_ids])
            patient.append((admission_rec[i], gth_ids, text_rec[i],in_ids,real_ids,train_enc_inp))
        records.append(patient)     
    dill.dump(obj=records, file=open(ehr_sequence_file, "wb"))
    return records
       
        

def check_avage_len(df):
    c_nums=[]
    d_nums=[]
    m_nums=[]
    for index, row in df.iterrows():
        patient = []
        chief = tokenizer.tokenize(row['chief'])
        chief_label = tokenizer.convert_tokens_to_ids(chief)
        his = tokenizer.tokenize(row['his'])
        his_label = tokenizer.convert_tokens_to_ids(his)
        med = tokenizer.tokenize(row['med'])
        med_label = tokenizer.convert_tokens_to_ids(med)
        c_nums.append(len(chief_label))
        d_nums.append(len(his_label))
        m_nums.append(len(med_label))
    c_nums=np.array(c_nums)
    d_nums=np.array(d_nums)
    m_nums=np.array(m_nums)
    print(np.percentile(c_nums,90),np.percentile(d_nums,70),np.percentile(m_nums,70))
    pass

if __name__ == "__main__":
    data = dill.load(open('/home/linhz/med/data_mimic4_mulvisit.pkl', 'rb'))
    data.dropna(axis = 0, how='any',subset = ['chief','med','his','SYM_LIST','ICD_C_V','ATC3'],inplace=True )
    tokenizer = AutoTokenizer.from_pretrained('biobart-v2-base')
    vocabulary_file = "/home/linhz/med/case3_1/voc_final_mimic4.pkl"
    ehr_sequence_file = "/home/linhz/med/case3_1/records_final_mimic4.pkl"
    sym_voc, diag_voc, med_voc = create_str_token_mapping(data,vocabulary_file) 
    print("obtain voc")
    tokenizer = AutoTokenizer.from_pretrained('biobart-v2-base')

    #detect_lengths(data,tokenizer)
    records = create_patient_record_fix(data, sym_voc, diag_voc, med_voc, tokenizer, ehr_sequence_file)
    print("obtain ehr sequence data")